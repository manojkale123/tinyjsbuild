// Exports the "table" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/table')
//   ES2015:
//     import 'tinymce/plugins/table'
require('./plugin.js');